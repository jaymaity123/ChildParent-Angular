import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  packageName: string = 'Goa';
  outputCost:number = 0;


  doClick(packageName:string)
  {
    this.packageName = packageName;
    console.log(" do click called , change the name "+this.packageName);
  }


  getCostFromChild(eventEmitterValue:number)
  {
    this.outputCost = eventEmitterValue;
  }
}
